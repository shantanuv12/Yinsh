#!/bin/bash

python yinshbot.py
